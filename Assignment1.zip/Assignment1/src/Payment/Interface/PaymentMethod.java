package Payment.Interface;

public interface PaymentMethod {
    String paymentDetail();
}
